import json
from django.http import HttpResponse, JsonResponse,Http404
from .forms import  CustomerForm
from django.shortcuts import render, get_object_or_404, redirect
from .models import Customer,InventorySellable,InventorySellable2
from django.core.mail import send_mail
from django.core.paginator import Paginator
from django.contrib.auth import authenticate,login,logout
import requests
from django.views.generic.edit import FormView

def home(request):
    return render(request, 'home.html')




def sellable_stock(request):
    if request.method == 'GET':

        response = requests.get('http://127.0.0.1:8000/sellable_inventory/')

        if response.status_code == 200:
            commands = response.json()


            formatted_commands = []
            for command in commands:
                formatted_command = {
                    'tel_model_mark_name': command['tel_model__mark__name'],
                    'tel_model_model': command['tel_model__model'],
                    'stockage_name': command['stockage__name'],
                    'color_name': command['color__name'],
                    'condition': command['condition']
                }
                formatted_commands.append(formatted_command)


            InventorySellable.objects.all().delete()


            for command in formatted_commands:
                InventorySellable.objects.create(
                    tel_model_mark_name=command['tel_model_mark_name'],
                    tel_model_model=command['tel_model_model'],
                    stockage_name=command['stockage_name'],
                    color_name=command['color_name'],
                    condition=command['condition']
                )

            context = {
                'sellable_items': formatted_commands,
            }

            return render(request, 'sellable_stock.html', context)
        else:
            return JsonResponse({'success': False, 'error': 'Failed to fetch data'})
    else:

        return JsonResponse({'success': False, 'error': 'Invalid request method'})

def sellable_stock2(request):
    if request.method == 'GET':
        response = requests.get('http://127.0.0.1:8000/sellable_inventory2/')

        if response.status_code == 200:
            commands = response.json()

            formatted_commands = []
            for command in commands:
                formatted_command = {
                    'tel_model_mark_name': command['tel_model__mark__name'],
                    'tel_model_model': command['tel_model__model'],
                    'stockage_name': command['stockage__name'],
                    'color_name': command['color__name'],
                    'condition': command['condition']
                }
                formatted_commands.append(formatted_command)

            InventorySellable2.objects.all().delete()

            for command in formatted_commands:
                InventorySellable2.objects.create(
                    tel_model_mark_name=command['tel_model_mark_name'],
                    tel_model_model=command['tel_model_model'],
                    stockage_name=command['stockage_name'],
                    color_name=command['color_name'],
                    condition=command['condition']
                )

            context = {
                'sellable_items': formatted_commands,  # Update the context variable name
            }

            return render(request, 'sellable_stock2.html', context)  # Update the template name
        else:
            return JsonResponse({'success': False, 'error': 'Failed to fetch data'})
    else:
        return JsonResponse({'success': False, 'error': 'Invalid request method'})

def stockw(request):
    if request.method == 'GET':

        sellable_items = InventorySellable.objects.all()

        context = {
            'sellable_items': sellable_items,
        }

        return render(request, 'stockw.html', context)
    else:
        return JsonResponse({'success': False, 'error': 'Invalid request method'})



def stockh(request):
    if request.method == 'GET':
        # Retrieve sellable inventory items from the database
        sellable_items = InventorySellable2.objects.all()

        context = {
            'sellable_items': sellable_items,
        }

        return render(request, 'stockh.html', context)
    else:
        return JsonResponse({'success': False, 'error': 'Invalid request method'})

def filter_sellable_stock(request):
    if request.method == 'GET':

        mark = request.GET.get('mark')
        model = request.GET.get('model')
        color = request.GET.get('color')
        stockage = request.GET.get('stockage')
        grade = request.GET.get('grade')


        sellable_items = InventorySellable.objects.all()


        mark_choices = sellable_items.values_list('tel_model_mark_name', flat=True).distinct()
        model_choices = sellable_items.values_list('tel_model_model', flat=True).distinct()
        color_choices = sellable_items.values_list('color_name', flat=True).distinct()
        stockage_choices = sellable_items.values_list('stockage_name', flat=True).distinct()
        grade_choices = ['A', 'B', 'C', 'D']


        if mark:
            sellable_items = sellable_items.filter(tel_model_mark_name=mark)
        if model:
            sellable_items = sellable_items.filter(tel_model_model=model)
        if color:
            sellable_items = sellable_items.filter(color_name=color)
        if stockage:
            sellable_items = sellable_items.filter(stockage_name=stockage)
        if grade:
            sellable_items = sellable_items.filter(condition=grade)


        context = {
            'mark_choices': mark_choices,
            'sellable_items': sellable_items,
            'model_choices': model_choices,
            'color_choices': color_choices,
            'stockage_choices': stockage_choices,
            'grade_choices': grade_choices,
            'selected_mark': mark,
            'selected_model': model,
            'selected_color': color,
            'selected_stockage': stockage,
            'selected_grade': grade,
        }

        return render(request, 'stockw.html', context)
    else:

        return JsonResponse({'success': False, 'error': 'Invalid request method'})

def filter_sellable_stock2(request):
    if request.method == 'GET':

        mark = request.GET.get('mark')
        model = request.GET.get('model')
        color = request.GET.get('color')
        stockage = request.GET.get('stockage')
        grade = request.GET.get('grade')


        sellable_items = InventorySellable2.objects.all()


        mark_choices = sellable_items.values_list('tel_model_mark_name', flat=True).distinct()
        model_choices = sellable_items.values_list('tel_model_model', flat=True).distinct()
        color_choices = sellable_items.values_list('color_name', flat=True).distinct()
        stockage_choices = sellable_items.values_list('stockage_name', flat=True).distinct()
        grade_choices = ['A', 'B', 'C', 'D']


        if mark:
            sellable_items = sellable_items.filter(tel_model_mark_name=mark)
        if model:
            sellable_items = sellable_items.filter(tel_model_model=model)
        if color:
            sellable_items = sellable_items.filter(color_name=color)
        if stockage:
            sellable_items = sellable_items.filter(stockage_name=stockage)
        if grade:
            sellable_items = sellable_items.filter(condition=grade)


        context = {
            'mark_choices': mark_choices,
            'sellable_items': sellable_items,
            'model_choices': model_choices,
            'color_choices': color_choices,
            'stockage_choices': stockage_choices,
            'grade_choices': grade_choices,
            'selected_mark': mark,
            'selected_model': model,
            'selected_color': color,
            'selected_stockage': stockage,
            'selected_grade': grade,
        }

        return render(request, 'stockh.html', context)
    else:

        return JsonResponse({'success': False, 'error': 'Invalid request method'})






def checkout(request, item_id):
    try:
        sellable_item = InventorySellable.objects.get(id=item_id)
    except InventorySellable.DoesNotExist:
        raise Http404("Item does not exist")

    if request.method == 'POST':
        form = CustomerForm(request.POST)

        if form.is_valid():
            name = form.cleaned_data['name']
            address = form.cleaned_data['address']
            phone = form.cleaned_data['phone']
            email = form.cleaned_data['email']


            customer = Customer.objects.create(
                name=name,
                address=address,
                phone=phone,
                email=email
            )


            sellable_item.delete()


            send_mail(
                'Confirmation Email',
                'Thank you for your order. Your item will be shipped soon.',
                'example@example.com',
                [email],
                fail_silently=False
            )

            send_mail(
                'New Order Notification',
                f'New order received for item(W): {sellable_item.tel_model_mark_name},{sellable_item.tel_model_model},{sellable_item.stockage_name},{sellable_item.color_name},{sellable_item.condition}',
                'example@example.com',  # Replace with your email address
                ['734551538@qq.com'],  # Replace with the desired recipient email address
                fail_silently=False
            )

            return redirect('checkout_success')
    else:
        form = CustomerForm()

    context = {
        'form': form,
        'item_id': item_id,
    }

    return render(request, 'checkout.html', context)



def checkout_success(request):
    return render(request, 'checkout_success.html')

def checkout2(request, item_id):
    try:
        sellable_item = InventorySellable2.objects.get(id=item_id)
    except InventorySellable2.DoesNotExist:
        raise Http404("Item does not exist")

    if request.method == 'POST':
        form = CustomerForm(request.POST)

        if form.is_valid():
            name = form.cleaned_data['name']
            address = form.cleaned_data['address']
            phone = form.cleaned_data['phone']
            email = form.cleaned_data['email']


            customer = Customer.objects.create(
                name=name,
                address=address,
                phone=phone,
                email=email
            )


            sellable_item.delete()


            send_mail(
                'Confirmation Email',
                'Thank you for your order. Your item will be shipped soon.',
                'sender@example.com',
                [email],
                fail_silently=False
            )


            send_mail(
                'New Order Notification',
                f'New order received for item (H): {sellable_item.tel_model_mark_name},{sellable_item.tel_model_model},{sellable_item.stockage_name},{sellable_item.color_name},{sellable_item.condition}',
                'sender@example.com',
                ['734551538@qq.com'],
                fail_silently=False
            )

            return redirect('checkout_success')
    else:
        form = CustomerForm()

    context = {
        'form': form,
        'item_id': item_id,
    }

    return render(request, 'checkout2.html', context)


def send_confirmation_email(customer, additional_recipient=None, item=None):
    subject = 'Confirmation Email'
    from_email = 'zzhixian19@gmail.com'

    if additional_recipient:
        if item:

            message = f'Dear unitechnologie, the customer has selected the following item:\n\nMark: {item.tel_model_mark_name}\nModel: {item.tel_model_model}\nColor: {item.color_name}\nStockage: {item.stockage_name}\nGrade: {item.condition}'
        else:

            message = 'Dear unitechnologie, please prepare an item.'

        recipient_list = [additional_recipient]
    else:

        message = f'Dear {customer.name}, thank you for your order. We have received your information.'

        recipient_list = [customer.email]

    send_mail(subject, message, from_email, recipient_list)





