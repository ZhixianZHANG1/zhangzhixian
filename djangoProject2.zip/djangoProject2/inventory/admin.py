from django.contrib import admin
from .models import InventorySellable,Customer,InventorySellable2

admin.site.register(InventorySellable)
admin.site.register(Customer)
admin.site.register(InventorySellable2)
