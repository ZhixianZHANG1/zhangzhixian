from django import forms
from .models import  InventorySellable,InventorySellable2




class InventorySellableFilterForm(forms.Form):
    mark_choices = [('', '---')] + list(InventorySellable.objects.values_list('tel_model_mark_name', 'tel_model_mark_name').distinct())
    model_choices = [('', '---')] + list(InventorySellable.objects.values_list('tel_model_model', 'tel_model_model').distinct())
    color_choices = [('', '---')] + list(InventorySellable.objects.values_list('color_name', 'color_name').distinct())
    stockage_choices = [('', '---')] + list(InventorySellable.objects.values_list('stockage_name', 'stockage_name').distinct())
    grade_choices = [('', '---')] + list(InventorySellable.objects.values_list('condition', 'condition').distinct())  # 根据实际情况添加Grade选项

    model = forms.ChoiceField(choices=model_choices, required=False)
    color = forms.ChoiceField(choices=color_choices, required=False)
    stockage = forms.ChoiceField(choices=stockage_choices, required=False)
    grade = forms.ChoiceField(choices=grade_choices, required=False)

class InventorySellableFilterForm2(forms.Form):
        mark_choices = [('', '---')] + list(
            InventorySellable2.objects.values_list('tel_model_mark_name', 'tel_model_mark_name').distinct())
        model_choices = [('', '---')] + list(
            InventorySellable2.objects.values_list('tel_model_model', 'tel_model_model').distinct())
        color_choices = [('', '---')] + list(
            InventorySellable2.objects.values_list('color_name', 'color_name').distinct())
        stockage_choices = [('', '---')] + list(
            InventorySellable2.objects.values_list('stockage_name', 'stockage_name').distinct())
        grade_choices = [('', '---')] + list(
            InventorySellable2.objects.values_list('condition', 'condition').distinct())  # 根据实际情况添加Grade选项

        model = forms.ChoiceField(choices=model_choices, required=False)
        color = forms.ChoiceField(choices=color_choices, required=False)
        stockage = forms.ChoiceField(choices=stockage_choices, required=False)
        grade = forms.ChoiceField(choices=grade_choices, required=False)


class CustomerForm(forms.Form):
    name = forms.CharField(max_length=100)
    address = forms.CharField(max_length=200)
    phone = forms.CharField(max_length=20)
    email = forms.EmailField(max_length=50)
